package com.goldscope_pro.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
